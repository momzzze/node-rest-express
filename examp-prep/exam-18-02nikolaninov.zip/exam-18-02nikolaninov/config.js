
const SECRET = 'dsaidufhq9gh3298rghitjuntjentljfe';

module.exports={
    SECRET,
}